
Jenkins Infrastructure
----------------------

The scripts in this directory serve as plumbing for running the protobuf
tests under Jenkins.
